﻿//using Milestone1.MainWindow.xaml;
using Npgsql;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Data;
using System;

namespace Milestone1
{

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public Business selectedBusiness;
        public Categories selectedCategories;
        public class Business
        {
            public string name { get; set; }
            public string state { get; set; }
            public string city { get; set; }
            public string address { get; set; }
            public string category { get; set; }
            public double stars { get; set; }
            public int review_count { get; set; }
            public double review_ratings { get; set; }
            public int num_checkins { get; set; }


        }
        public class Review
        {
            public string review_id { get; set; }
            public string review_text { get; set; }
            public string review_date { get; set; }
            public string Business_id { get; set; }

        }
        public class FriendReview
        {
            public string user_name { get; set; }
            public string business_name { get; set; }
            public string review_date { get; set; }
            public string review_text { get; set; }
        }
        public class User
        {
            public string user_id { get; set; }
            public double average_stars { get; set; }
            public int fans { get; set; }
            public string name { get; set; }
            public int cool { get; set; }
            public int funny { get; set; }
            public int useful { get; set; }
            public int review_count { get; set; }
            public string yelping_since { get; set; }

        }
        public class Categories
        {
            public string Business_id { get; set; }
            public string Categories_name { get; set; }
        }

        public MainWindow()
        {
            InitializeComponent();
            addStates();
            addColumns2Grid();
            businessGrid.Items.Clear();
            addRating();
        }

        private string buildConnString()
        {
            return "Host = localhost; Username = postgres; password = teamsk; Database = yelpdb;";
        }

        public void addStates()
        {

            using (var conn = new NpgsqlConnection(buildConnString()))
            {
                conn.Open();
                using (var cmd = new NpgsqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "SELECT distinct state FROM business ORDER BY state;";
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            statelist.Items.Add(reader.GetString(0));
                        }
                    }
                }
                conn.Close();
            }
        }
        public void addCities()
        {
            using (var conn = new NpgsqlConnection(buildConnString()))
            {
                conn.Open();
                using (var cmd = new NpgsqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "SELECT distinct city FROM business WHERE state = '" + statelist.SelectedItem.ToString() + "' ORDER by city;";
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            citylist.Items.Add(reader.GetString(0));
                        }
                    }
                }
                conn.Close();
            }
        }
        public void addZipcodes()
        {
            using (var conn = new NpgsqlConnection(buildConnString()))
            {
                conn.Open();
                using (var cmd = new NpgsqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "SELECT distinct zipcode FROM business WHERE state = '" + statelist.SelectedItem.ToString() + "' AND city ='" + citylist.SelectedItem.ToString() + "' ORDER by zipcode;";
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            zipcodelist.Items.Add(reader.GetString(0));
                        }
                    }
                }
                conn.Close();
            }
        }
        public void addCategories()
        {
            using (var conn = new NpgsqlConnection(buildConnString()))
            {
                conn.Open();
                using (var cmd = new NpgsqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "SELECT distinct categories_name FROM Categories, Business WHERE Business.Business_id = Categories.Business_id AND state = '" + statelist.SelectedItem.ToString() + "' AND city ='" + citylist.SelectedItem.ToString() + "'AND zipcode ='" + zipcodelist.SelectedItem.ToString() + "'  ORDER by categories_name;";


                    //DataTable dt = new DataTable("business");
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            categorylist.Items.Add(reader.GetString(0));
                        }
                    }
                }
                conn.Close();
            }
        }
        public void addRating()
        {
            rating.Items.Add("5");
            rating.Items.Add("4");
            rating.Items.Add("3");
            rating.Items.Add("2");
            rating.Items.Add("1");
        }



        public void addColumns2Grid()
        {
                    DataGridTextColumn col1 = new DataGridTextColumn();
                    col1.Header = "Business Name";
                    col1.Binding = new Binding("name");
                    businessGrid.Columns.Add(col1);

                    DataGridTextColumn col2 = new DataGridTextColumn();
                    col2.Header = "Address";
                    col2.Binding = new Binding("address");
                    businessGrid.Columns.Add(col2);

                    DataGridTextColumn col3 = new DataGridTextColumn();
                    col3.Header = "City";
                    col3.Binding = new Binding("city");
                    businessGrid.Columns.Add(col3);

                    DataGridTextColumn col4 = new DataGridTextColumn();
                    col4.Header = "State";
                    col4.Binding = new Binding("state");
                    businessGrid.Columns.Add(col4);

                    DataGridTextColumn col5 = new DataGridTextColumn();
                    col5.Header = "Stars";
                    col5.Binding = new Binding("stars");
                    businessGrid.Columns.Add(col5);

                    DataGridTextColumn col6 = new DataGridTextColumn();
                    col6.Header = "# of review";
                    col6.Binding = new Binding("review_count");
                    businessGrid.Columns.Add(col6);

                    DataGridTextColumn col7 = new DataGridTextColumn();
                    col7.Header = "Review Rating";
                    col7.Binding = new Binding("review_ratings");
                    businessGrid.Columns.Add(col7);

                    DataGridTextColumn col8= new DataGridTextColumn();
                    col8.Header = "Total Checkin";
                    col8.Binding = new Binding("num_checkins");
                    businessGrid.Columns.Add(col8);



            DataGridTextColumn col9 = new DataGridTextColumn();
            col9.Header = "User Name";
            col9.Binding = new Binding("user_name");
            reviewGrid.Columns.Add(col9);

            DataGridTextColumn col10 = new DataGridTextColumn();
            col10.Header = "Review Date";
            col10.Binding = new Binding("review_date");
            reviewGrid.Columns.Add(col10);

            DataGridTextColumn col11 = new DataGridTextColumn();
            col11.Header = "Review Text";
            col11.Binding = new Binding("review_text");
            reviewGrid.Columns.Add(col11);
        }
                
        private void Statelist_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            businessGrid.Items.Clear();
            //citylist.SelectedValue = -1;
            citylist.Items.Clear();
            zipcodelist.Items.Clear();
            categorylist.Items.Clear();

            businessCategoriesList.Items.Clear();

            if (statelist.SelectedIndex > -1)
            {
                using (var conn = new NpgsqlConnection(buildConnString()))
                {
                    conn.Open();
                    using (var cmd = new NpgsqlCommand())
                    {
                        cmd.Connection = conn;
                        cmd.CommandText = "SELECT name, state FROM business WHERE state = '" + statelist.SelectedItem.ToString() + "';";
                        /*using (var reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                businessGrid.Items.Add(new Business() { name = reader.GetString(0), state = reader.GetString(1) });
                            }
                        }*/
                    }
                    conn.Close();
                    addCities();

                }

            }
        }

        private void Citylist_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            businessGrid.Items.Clear();
            zipcodelist.Items.Clear();
            categorylist.Items.Clear();
            if (citylist.SelectedIndex > -1)
            {
                using (var conn = new NpgsqlConnection(buildConnString()))
                {
                    conn.Open();
                    using (var cmd = new NpgsqlCommand())
                    {
                        cmd.Connection = conn;
                        cmd.CommandText = "SELECT name, state, city FROM business WHERE city = '" + citylist.SelectedItem.ToString() + "' AND state = '" + statelist.SelectedItem.ToString() + "' ORDER by name;";
                        /* using (var reader = cmd.ExecuteReader())
                         {
                             while (reader.Read())
                             {
                                 businessGrid.Items.Add(new Business() { name = reader.GetString(0), state = reader.GetString(1), city = reader.GetString(2) });
                             }
                         }*/
                    }
                    conn.Close();
                    addZipcodes();
                }

            }
        }

        private void Zipcodelist_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            businessGrid.Items.Clear();
            categorylist.Items.Clear();
            if (zipcodelist.SelectedIndex > -1)
            {
                using (var conn = new NpgsqlConnection(buildConnString()))
                {
                    conn.Open();
                    using (var cmd = new NpgsqlCommand())
                    {
                        cmd.Connection = conn;
                        cmd.CommandText = "SELECT name, state, city, address, stars, review_count, review_ratings, num_checkins FROM business WHERE zipcode = '" + zipcodelist.SelectedItem.ToString() + "' AND city = '" + citylist.SelectedItem.ToString() + "' AND state = '" + statelist.SelectedItem.ToString() + "' ORDER by name;";
                        using (var reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                businessGrid.Items.Add(new Business() { name = reader.GetString(0), state = reader.GetString(1), city = reader.GetString(2), address = reader.GetString(3), stars = reader.GetDouble(4), review_count = reader.GetInt32(5), review_ratings = reader.GetDouble(6), num_checkins = reader.GetInt32(7) });
                            }
                        }
                    }
                    conn.Close();
                    addCategories();
                }

            }
        }
        private void Categorylist_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            businessGrid.Items.Clear();
            if (categorylist.SelectedIndex > -1)
            {
                using (var conn = new NpgsqlConnection(buildConnString()))
                {
                    conn.Open();
                    using (var cmd = new NpgsqlCommand())
                    {
                        cmd.Connection = conn;
                        cmd.CommandText = "SELECT name, state, city, address, stars, review_count, review_ratings, num_checkins FROM business, Categories WHERE Business.Business_id = Categories.Business_id AND categories_name = '" + categorylist.SelectedItem.ToString() + "' AND zipcode = '" + zipcodelist.SelectedItem.ToString() + "' AND city = '" + citylist.SelectedItem.ToString() + "' AND state = '" + statelist.SelectedItem.ToString() + "' ORDER by name;";
                        using (var reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                businessGrid.Items.Add(new Business() { name = reader.GetString(0), state = reader.GetString(1), city = reader.GetString(2), address = reader.GetString(3), stars = reader.GetDouble(4), review_count = reader.GetInt32(5), review_ratings = reader.GetDouble(6), num_checkins = reader.GetInt32(7) });
                            }
                        }
                    }
                    conn.Close();
                }

            }
        }


        private void addReviewBtn_Click(object sender, RoutedEventArgs e)
        {
            Review tempReview = new Review();
            tempReview.review_text = addReviewTxt.Text;
            // had to update 1.entering stars and 2. updating on the database.  and other thing - read description.


        }



        
        private void BusinessGrid_SelectedCellsChanged(object sender, SelectedCellsChangedEventArgs e)
        {
            businessCategoriesList.Items.Clear();

            //string row = businessGrid.SelectedIndex.ToString();
            selectedBusiness = (Business)businessGrid.SelectedItem;
            //SelectedBusiness = (Business)businessGrid.SelectedItems[0].ToString();
            businessName.Text = selectedBusiness.name;
            businessAddress.Text = selectedBusiness.address;

            using (var conn = new NpgsqlConnection(buildConnString()))
            {
                conn.Open();
                using (var cmd = new NpgsqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "SELECT Categories_name FROM Categories, Business WHERE Business.Business_id = Categories.Business_id AND name = '" + selectedBusiness.name.ToString() + "';";


                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {

                            ListViewItem Lv = new ListViewItem();// (reader[0].ToString()) ;
                            Lv.Content = reader[0].ToString();
                            businessCategoriesList.Items.Add(Lv);
                            //businessAddress.Text = selectedBusiness.address;
                            //businessGrid.Items.Add(new Business() { name = reader.GetString(0), state = reader.GetString(1), city = reader.GetString(2), address = reader.GetString(3), stars = reader.GetDouble(4), review_count = reader.GetInt32(5), review_ratings = reader.GetDouble(6), num_checkins = reader.GetInt32(7) });
                        }
                    }

 
                }
                conn.Close();
            }

            /*
            using (var conn = new NpgsqlConnection(buildConnString()))
            {
                conn.Open();
                using (var cmd = new NpgsqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "SELECT Users.name, review_date, text FROM  Users, Review, Business WHERE Business.Business_id = Review.Business_id AND Users.user_id = Review.user_id AND Business.name = '" + selectedBusiness.name.ToString() + "';";
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            reviewGrid.Items.Add(new FriendReview() { user_name = reader.GetString(0), review_date = reader.GetString(1), review_text = reader.GetString(2) });
                        }
                    }


                }
                conn.Close();
            }*/
            


        }
      
    }
}